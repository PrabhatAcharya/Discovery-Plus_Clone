import React from 'react'

function Hero() {
  return (
    <div>
      
    </div>
  )
}

export default Hero
