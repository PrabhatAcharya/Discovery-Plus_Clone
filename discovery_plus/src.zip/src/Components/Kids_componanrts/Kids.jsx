import React from 'react'
import Slider from './kids_craousel'
import Card from './Card' 


function Kids() {
  return (
    <div className='bg-black'>
      <Slider/>
      <Card/>
    </div>
  )
}

export default Kids
