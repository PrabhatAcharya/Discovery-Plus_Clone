
import {Slider} from "./slider"
// import {Caro} from "./manual_carousel"
import { Corosuel } from "./corosuel"
// import {Footer} from"./footer"
export const Home=()=> {
    return (
    <>
    <Corosuel />
     <Slider />

     </>
    )
}
